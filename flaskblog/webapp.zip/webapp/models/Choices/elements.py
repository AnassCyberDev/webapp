import enum


class ElemntType(enum.Enum):
    undefined = "undefined"
    MaiVil = "MaiVil"
    Appartement = "Appartement"
    TerraFerms = 'TerraFerms'
    MagCom = 'MagCom'
    BurPla = "BurPla"

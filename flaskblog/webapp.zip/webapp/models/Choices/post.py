import enum


class PostType(enum.Enum):
    aLouer = "A louer"
    aVend = "A vendre"
    undefined = "undefined"

def switch_bool(x):
    if x :
        if x =='true':
            return True
        elif x == 'false':
            return False
    else:
        return False